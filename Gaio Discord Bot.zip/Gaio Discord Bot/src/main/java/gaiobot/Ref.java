package gaiobot;

public class Ref{
    /**
     * 
     */
    public static String token = "NTQyMTIzOTQ2MTgzNjIyNjg2.DzpcFQ.NFfLyeRLX97-jWzQTfKSGJoo618";
    public static String prefix = ">";
    public static String version = "0.1";
    public static final int defPower = 0;
    public static long msgTimer = 3000;
    public static String welcome = "";
}